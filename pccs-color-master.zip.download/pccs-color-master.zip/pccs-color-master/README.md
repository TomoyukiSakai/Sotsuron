# pccs-color

Practical Color Co-ordinate System

### Reference

* http://www.wsj21.net/ghp/ghp0c_03.html
* https://farm6.staticflickr.com/5486/9924819306_84fec9c3dd_o.jpg

### HTML Tryit editor

* https://www.w3schools.com/html/tryit.asp?filename=tryhtml_default

### Usage

	getPccsHtml.sh <toneName1 toneName2 toneName3 ...>

Ex: ./getPccsHtml.sh v b lt p s sf ltg dp d g dk dkg > pccsWeb.html

